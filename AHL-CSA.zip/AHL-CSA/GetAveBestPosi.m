function AveP=GetAveBestPosi(pop,NL)
global N;
%找每层的前0.4

%每层的个数
numl=floor(N/NL);
%取得个数
if numl>=5
    n=floor(numl*0.4);
else
    n=1;
end

count=1;
for i=1:NL
    index=(i-1)*numl;
    for j=1:n
        num=index+j;
        a(count,:)=pop(num).RelPos;
        count=count+1;
    end
end

AveP=mean(a);
