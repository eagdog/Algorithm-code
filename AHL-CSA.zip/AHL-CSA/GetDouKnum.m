%从1到numL随机选择一个非i的数,考虑numL等于1的情况
function [J,K] = GetDouKnum(i,numL,NL)%当前i,每一层个数，当前层

%获取k
 if NL==1
         %取1到numL非i的数组A
        a=[];
        b=[];count=0;
        for j=1:i-1
            a(j)=j;
        end
        for j=i+1:numL
            count=count+1;
            b(count)=j;
        end
        A=[a,b];
        Knum=A(randi(numel(A),1,2));
        K=Knum(1);
        J=Knum(2);
        if J>K
            t=J;
            J=K;
            K=t;
        end
     %非第一层
 elseif NL==2
     %从第一层选两个
     Knum=randperm(numL,2);
      K=Knum(1);
      J=Knum(2);
      if J>K
          t=J;
          J=K;
          K=t;
      end
 else
     %不同层选
     NLnum=NL-1;
     DouNLs=randperm(NLnum,2);
     DNL1=DouNLs(1);
     DNL2=DouNLs(2);
     if DNL1>DNL2
         t=DNL1;
         DNL1=DNL2;
         DNL2=t;
     end
     %从这两层分别选出两个
     knumL1=randperm(numL,1);
     J=numL*(DNL1-1)+knumL1;
     knumL2=randperm(numL,1);
     K=numL*(DNL2-1)+knumL2;
 end