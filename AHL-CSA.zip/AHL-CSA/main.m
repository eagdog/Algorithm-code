clc;
clear;
close;
%% 将数据集加载

%data=LoadData('1haberman.mat');  %0.8361；0.169；0.67
%data=LoadData('2australia.mat');   %0.8843
%data=LoadData('3balance-scale.mat'); %0.8424
%data=LoadData('4Breastcancer.mat'); %[0,1,0,0,0,1,1,1,1,0] 1
%data=LoadData('5contraceptive.mat'); %0.5418
%data=LoadData('6ecoli.mat');           %0.8741
data=LoadData('7glass.mat');              %0.7971
%data=LoadData('8inosphere.mat');           %0.9829
%data=LoadData('9iris.mat');                        %1
%data=LoadData('10sonar.mat');%[1,1,1,1,1,1,1,1,1,1,1,0.975609756097561,0.975609756097561,0.975609756097561,0.975609756097561,0.975609756097561,0.975609756097561,0.975609756097561,0.975609756097561,0.975609756097561,0.975609756097561,0.975609756097561,0.975609756097561,0.975609756097561,0.975609756097561,0.975609756097561,0.975609756097561,0.975609756097561,0.951219512195122,0.951219512195122]
%data=LoadData('11wine.mat');  %1
%data=LoadData('12zoo.mat');   %1
%data=LoadData('13vehicle.mat');%BGOAM是0.7704
%data=LoadData('14dermatology.mat');        %BGOAM是1
%data=LoadData('15lymphography.mat');   %BGOAM是0.9118
%data=LoadData('16Tic-Tac-Toe.mat');             %[0.853403141361257,0.853403141361257,0.853403141361257,0.853403141361257,0.853403141361257,0.853403141361257,0.853403141361257,0.853403141361257,0.853403141361257,0.853403141361257,0.853403141361257,0.853403141361257,0.853403141361257,0.853403141361257,0.853403141361257,0.853403141361257,0.853403141361257,0.853403141361257,0.853403141361257,0.853403141361257,0.853403141361257,0.853403141361257,0.853403141361257,0.853403141361257,0.853403141361257,0.853403141361257,0.853403141361257,0.853403141361257,0.853403141361257,0.853403141361257]
%data=LoadData('breastEW.mat');  % 0.987
%data=LoadData('SpectHeart.mat');   %0.9082


HO = cvpartition(data.t,'holdout',0.2,'Stratify',false);
%HO2 = cvpartition(data.t,'KFold',10,'Stratify',false);
%HO = cvpartition(data.t,'KFold',10,'Stratify',false);
CostFunction=@(r)CostFit(r,data,HO);
%CostFunction=@(r)myCost(r,data,HO);

global dim;
dim=data.nx;             % Number of Decision Variables 决策变量个数


sumbfit=0;
sumbrite=0;
sumacc=0;
for i=1:1
    [bestfit30(i),rate30(i),acc30(i)]=DEHHLCSA2(CostFunction);
    sumbfit=sumbfit+bestfit30(i);
    sumbrite=sumbrite+rate30(i);
    sumacc=sumacc+acc30(i);
end
%     ave30=sumbfit/30;
%     averite30=sumbrite/30;
%     aveacc30=sumacc/30;
 [sortbestfit,index]=sort(bestfit30);
% minbestfit=sortbestfit(1);
% maxbestfit=sortbestfit(end);

acc30=acc30(index);
rate30=rate30(index);

sumf=0;
sumrate=0;
suma=0;
for i=1:20
    sumf=sumf+sortbestfit(i);
    sumrate=sumrate+rate30(i);
    suma=suma+acc30(i);
end
bf=sumf/20;
br=sumrate/20;
ba=suma/20;
    StdAcc=std(acc30(1:20));
    StdFit=std(bestfit30(1:20));
    MaxAcc=max(acc30);
    
    plot(acc30,'b*');
    xlabel('Error');
    ylabel('itreter');
    title('datas ');
