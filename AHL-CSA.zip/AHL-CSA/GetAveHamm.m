function AveHamm=GetAveHamm(pop)
count=0;
sumham=0;
for i=1:numel(pop)-1
    a=pop(i).Position;
    for j=i+1:numel(pop)
        b=pop(j).Position;
        dis = pdist([a;b], 'hamming');
        sumham=sumham+dis;
        count=count+1;
    end
end
AveHamm=sumham/count;
