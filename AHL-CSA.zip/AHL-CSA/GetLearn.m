    %算子公式：deta=0.04
    %1.Xi+F(Xgbest-Xi)+F(Xr1-Xr2)+deta(X'-Xi)
    %2.Xi+F(Xr1-Xi)+F(Xr2-Xr3)+deta(X'-Xi)
    %3.Xi+F(Xgbest-Xworst)+rand(Xgbest-Xpbest)+deta(X'-Xi)
function learn= GetLearn(popmem,pop,AvePosi,gbestRelp,worstRelp,NL)

    global N;
    F=rand*2-1;
    deta=0.04;
    %每层个数
    numL=floor(N/NL);
    mutNL1=floor(NL/3);
    mutNL2=2*mutNL1;
    
    %最后一层个数
    modNum=mod(N,NL);
    nLast=numL+modNum;
    
    for i=1:NL-1
        for j=1:numL
            index=(i-1)*numL+j;
            Xi=pop(index).RelPos;
            if i<=mutNL1
                [m,n]=GetDouKnum(j,numL,i);                                                %当前层的当前粒子,每一层个数，当前层
                learn(index,:)=F*(gbestRelp-Xi)+F*(popmem(m).RelPos-popmem(n).RelPos)+deta*(AvePosi-Xi);
            elseif i>mutNL1&&i<=mutNL2
                [m,n]=GetDouKnum(j,numL,i);                                                %当前层的当前粒子,每一层个数，当前层
                learn(index,:)=F*(popmem(m).RelPos-Xi)+F*(popmem(m).RelPos-popmem(n).RelPos)+deta*(AvePosi-Xi);
            elseif i>mutNL2
                [~,n]=GetDouKnum(j,numL,i);                                                %当前层的当前粒子,每一层个数，当前层
                learn(index,:)=F*(gbestRelp-worstRelp)+F*(gbestRelp-popmem(n).RelPos)+deta*(AvePosi-Xi);
            end
        end
    end
    %最后一层
    for i=1:nLast
        index=(NL-1)*numL+i;
         [~,n]=GetDouKnum(i,numL,NL);                                                %当前层的当前粒子,每一层个数，当前层
         learn(index,:)=F*(gbestRelp-worstRelp)+F*(gbestRelp-popmem(n).RelPos)+deta*(AvePosi-Xi);
    end
