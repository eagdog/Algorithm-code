%% 思路

% 将这个共享机制的更新公式作为一个偏移量
%Multi Strategy
%1.Xi+F(Xbest-Xi)+F(Xr1-Xr2)+mu(X'-Xi)
%2.Xi+F(Xr1-Xi)+F(Xr2-Xr3)+mu(X'-Xi)
%3.Xi+F(Xbest-Xworst)+rand(Xgbest-Xpbest)+mu(X'-Xi)

%使用汉明分层
%加入分裂和变异

%两种思路：1.像上面一样
%                   2.将这个共享机制的更新公式作为一个偏移量

function [fitness,rate,acc]=DEHHLCSA2(CostFunction)


%% BCSA 
global dim;
VarSize=[1 dim];   % Size of Decision Variables Matrix
global N;
N=50; % Flock (population) size
AP=0.1; % Awareness probability
global ub;
global lb;
flmax=2.5; % Flight length (fl)
flmin=1.5; % Flight length (fl)
l=-20; u=20; % Lower and upper bounds
ub=ones(1,dim).*u;
lb=ones(1,dim).*l;
tmax=300; % Maximum number of iterations (itermax)
pCR=0.1;

empty_individual.Position=[];
empty_individual.Cost=[];
empty_individual.RelPos=[];
empty_individual.fit=[];
pop=repmat(empty_individual,N,1);

%% 初始化种群
for i=1:N % Generation of initial solutions (position of crows)
    pop(i).RelPos=randi([l u],VarSize); % Position of the crows in the space
    pop(i).Position=Tranf(pop(i).RelPos);
    [pop(i).Cost,pop(i).fit]=CostFunction(pop(i).Position);
end

popnew=pop;
popmem=pop;

%计算这一次迭代的平均汉明值求分层数
AveHamm0=GetAveHamm(pop);
  
%% CSA Main Loop
    
for t=1:tmax 
    
%% Generation of random candidate crows for following (chasing)
    
        %计算第t次的平均汉明值
     AveHammt=GetAveHamm(popmem);
     
    %计算分层的数量
    temp=(AveHammt/AveHamm0)*N;
    
    if temp<2
        NL=4;
    elseif temp>=2&&temp<=N
        NL=floor(temp);
        if NL<4
            NL=4;
        elseif NL>N/2
            NL=N/2;
        end
    else
        NL=N/2;
    end
    NL
    %排序分层
    tfit=[popmem.fit];
    [~,index]=sort(tfit);
    popmem=popmem(index);
    gbestRelp=popmem(1).RelPos;
    worstRelp=popmem(end).RelPos;
    
    %计算种群的平均位置
    %AvePosi=GetAvePosi(popmem);
    %计算每个层次最优的平均位置
    AvePosi=GetAveBestPosi(popmem,NL);
    %时飞长度
    tvfl = ((1-(t/tmax))*flmax+(t/tmax)*flmin);
    num=ceil(N*rand(1,N));
    % Mutation
    learn=GetLearn(popmem,pop,AvePosi,gbestRelp,worstRelp,NL);
    %不同
    for i=1:N
        x=popmem(i).RelPos;
         if rand>AP 
            %学习策略
            popnew(i).RelPos= pop(i).RelPos+tvfl*rand*(popmem(num(i)).RelPos-pop(i).RelPos)+learn(i,:);  % Generation of a new position for crow i (state 1)
            popnew(i).RelPos=Bounds(  popnew(i).RelPos, lb, ub );
            popnew(i).Position=Tranf(popnew(i).RelPos);

         else
             popnew(i).RelPos=randi([l u],VarSize);
             popnew(i).Position=Tranf(popnew(i).RelPos);
         end
        [popnew(i).Cost,popnew(i).fit]=CostFunction(popnew(i).Position);%特选
        
        % Crossover
        y=popnew(i).RelPos;
        z=zeros(size(x));
        j0=randi([1 numel(x)]);
        for j=1:numel(x)
            if j==j0 || rand<=pCR
                z(j)=y(j);
            else
                z(j)=x(j);
            end
        end
        zPosition=Tranf(z);
        [zcost,zfit]=CostFunction(z);%特选
        if zfit<popnew(i).fit
            popnew(i).RelPos=z;
            popnew(i).Position=zPosition;
            popnew(i).fit=zfit;
            popnew(i).Cost=zcost;
        end
    end
    
   %% 种群更新
   for i=1:N 
        pop(i).RelPos=popnew(i).RelPos;
        if popnew(i).fit<popmem(i).fit
            popmem(i)=popnew(i);
        end
   end
        
end
 ttfit=[popmem.fit];
 [~,index]=sort(ttfit);
popmem=popmem(index);
fitness=popmem(1).fit;
rate=popmem(1).Cost(3);
acc=popmem(1).Cost(1);
end