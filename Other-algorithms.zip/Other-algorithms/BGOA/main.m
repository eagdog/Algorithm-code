clear; 
close all;
clc;

%data=LoadData('1haberman.mat');  %0.7525
%data=LoadData('2australia.mat');   %0.8843
%data=LoadData('3balance-scale.mat'); %0.8424
%data=LoadData('4Breastcancer.mat'); %[0,1,0,0,0,1,1,1,1,0] 1
%data=LoadData('5contraceptive.mat'); %0.5418
%data=LoadData('6ecoli.mat');           %0.8741
%data=LoadData('7glass.mat');              %0.7971
%data=LoadData('8inosphere.mat');           %0.9829
%data=LoadData('9iris.mat');                        %1
%data=LoadData('10sonar.mat');%
%data=LoadData('11wine.mat');  %1
%data=LoadData('12zoo.mat');   %1
%data=LoadData('13vehicle.mat');%
%data=LoadData('14dermatology.mat'); %
data=LoadData('15lymphography.mat');  %
%data=LoadData('16Tic-Tac-Toe.mat'); %[0.816753926701571,0.816753926701571,0.816753926701571,0.816753926701571,0.816753926701571,0.816753926701571,0.816753926701571,0.816753926701571,0.816753926701571,0.816753926701571,0.816753926701571,0.816753926701571,0.816753926701571,0.816753926701571,0.816753926701571,0.816753926701571,0.816753926701571,0.790575916230367,0.816753926701571,0.816753926701571,0.816753926701571,0.816753926701571,0.816753926701571,0.816753926701571,0.816753926701571,0.816753926701571,0.816753926701571,0.816753926701571,0.816753926701571,0.816753926701571]
%data=LoadData('breastEW.mat');  % 0.987
%data=LoadData('SpectHeart.mat');   %0.9082

% Set 20% data as validation set
ho = 0.2; 
% Hold-out method
HO = cvpartition(data.t,'HoldOut',ho,'Stratify',false);
CostFunction=@(r)FSCostFit(r,data,HO);

Max_iteration=100; % Maximum number of iterations
N=50; % Number of particles
dim=data.nx;             % Number of Decision Variables 决策变量个数

% BDA with a v-shaped transfer function
sumbfit=0;
sumbrite=0;
sumacc=0;
for i=1:30
    [fitness(i),rf(i),acc(i)] =binaryGOA(N, Max_iteration, dim, CostFunction);
     sumbfit=sumbfit+fitness(i);
    sumbrite=sumbrite+rf(i);
    sumacc=sumacc+acc(i);
end
    aveacc30=sumacc/30;
    ave30=sumbfit/30;
    averite30=sumbrite/30;
    
     StdAcc=std(acc);
    StdFit=std(fitness);
    MaxAcc=max(acc);
    
    
    plot(acc,'b*');
    xlabel('acc');
    ylabel('itreter');
    title('30次BDA准确率的图 ');