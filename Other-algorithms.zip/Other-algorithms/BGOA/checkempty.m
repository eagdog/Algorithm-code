function GrassHopperPositions = checkempty(GrassHopperPositions,dim,flag)
while numel(find(GrassHopperPositions==0))==numel(GrassHopperPositions)
    if flag==1
        tdim=dim-1;
    else
        tdim=dim;
    end
    GrassHopperPositions=round(rand(1,tdim));
   
end
