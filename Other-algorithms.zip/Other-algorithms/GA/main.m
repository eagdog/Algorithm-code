 clc;
 close;
 clear;
%data=LoadData('1haberman.mat');  %0.7525
%data=LoadData('2australia.mat');   %0.8843
%data=LoadData('3balance-scale.mat'); %0.8424
%data=LoadData('4Breastcancer.mat'); %[0,1,0,0,0,1,1,1,1,0] 1
%data=LoadData('5contraceptive.mat'); %0.5418
%data=LoadData('6ecoli.mat');           %0.8741
%data=LoadData('7glass.mat');              %0.7971
%data=LoadData('8inosphere.mat');           %0.9829
%data=LoadData('9iris.mat');                        %1
data=LoadData('10sonar.mat');%[1,0.975609756097561,1,0.975609756097561,0.975609756097561,1,0.975609756097561,0.975609756097561,0.975609756097561,0.975609756097561,0.975609756097561,0.975609756097561,1,1,0.975609756097561,0.975609756097561,0.975609756097561,0.975609756097561,0.975609756097561,0.975609756097561,0.975609756097561,0.975609756097561,0.975609756097561,0.975609756097561,1,0.975609756097561,0.975609756097561,0.975609756097561,0.975609756097561,0.975609756097561]
%data=LoadData('11wine.mat');  %1
%data=LoadData('12zoo.mat');   %1
%data=LoadData('13vehicle.mat');%[0.798816568047337,0.810650887573965,0.810650887573965,0.810650887573965,0.804733727810651,0.810650887573965,0.810650887573965,0.810650887573965,0.810650887573965,0.810650887573965,0.804733727810651,0.804733727810651,0.804733727810651,0.804733727810651,0.810650887573965,0.792899408284024,0.810650887573965,0.798816568047337,0.810650887573965,0.810650887573965,0.810650887573965,0.804733727810651,0.810650887573965,0.810650887573965,0.804733727810651,0.810650887573965,0.810650887573965,0.810650887573965,0.804733727810651,0.804733727810651]
%data=LoadData('14dermatology.mat'); %
%data=LoadData('15lymphography.mat');  %
%data=LoadData('16Tic-Tac-Toe.mat'); %
%data=LoadData('breastEW.mat');  % 0.987
%data=LoadData('SpectHeart.mat');   %0.9082
 
 HO = cvpartition(data.t,'holdout',0.2,'Stratify',false);
CostFunction=@(r)FeatureSelectionCost(r,data,HO);

dim=data.nx;             % Number of Decision Variables 决策变量个数
N=50; % Flock (population) size


sumbfit=0;
sumbrite=0;
sumacc=0;
for i=1:30
    [acc(i),fitness(i),rf(i)] = GA(dim,N,CostFunction);
     sumbfit=sumbfit+fitness(i);
    sumbrite=sumbrite+rf(i);
    sumacc=sumacc+acc(i);
end
     aveacc30=sumacc/30;
    avefit30=sumbfit/30;
    averite30=sumbrite/30;
    
     StdAcc=std(acc);
    StdFit=std(fitness);
    MaxAcc=max(acc);
    
    plot(acc,'b*');
    xlabel('acc');
    ylabel('itreter');
    title('30次GA准确率的图 ');