

%% GA Parameters
function [acc,fitness,rate]=GA(dim,N,CostFunction)

MaxIt=100;       % Maximum Number of Iterations
VarSize=[1 dim];   % Size of Decision Variables Matrix
pc=0.7;                 % Crossover Percentage
nc=2*round(pc*N/2);  % Number of Offsprings (Parnets)

pm=0.3;                 % Mutation Percentage
nm=round(pm*N);      % Number of Mutants

mu=0.1;         % Mutation Rate

beta=8;         % Selection Pressure


%% Initialization


empty_individual.Position=[];
empty_individual.Cost=[];
empty_individual.fit=[];

pop=repmat(empty_individual,N,1);

for i=1:N
    
    % Initialize Position
    pop(i).Position=randi([0 1],VarSize);
    
    % Evaluation
    [pop(i).Cost, pop(i).fit]=CostFunction(pop(i).Position);
    
end
%best
bestfitness=inf;
bestrate=0;
bestacc=0;
% Sort Population
tfit=[pop.fit];
[tfit, SortOrder]=sort(tfit);
pop=pop(SortOrder);

% Store Best Solution
bestfitness=pop(1).fit;
bestrate=pop(1).Cost(3);
bestacc=pop(1).Cost(1);
% Array to Hold Best Cost Values
BestCost=zeros(MaxIt,1);

% Store Cost
Worstfit=pop(N).fit;
Nwor=N;
while Worstfit==Inf
    Nwor=Nwor-1;
    Worstfit=pop(Nwor).fit;
end

%% Main Loop

for it=1:MaxIt
    
    P=exp(-beta*tfit/Worstfit);
    P=P/sum(P);
    
    % Crossover
    popc=repmat(empty_individual,nc/2,2);
    for k=1:nc/2
        
        % Select Parents Indices
        i1=RouletteWheelSelection(P);
        i2=RouletteWheelSelection(P);

        % Select Parents
        p1=pop(i1);
        p2=pop(i2);
        
        % Apply Crossover
        [popc(k,1).Position, popc(k,2).Position]=Crossover(p1.Position,p2.Position);
        
        % Evaluate Offsprings
        [popc(k,1).Cost, popc(k,1).fit]=CostFunction(popc(k,1).Position);
        [popc(k,2).Cost, popc(k,2).fit]=CostFunction(popc(k,2).Position);
        
    end
    popc=popc(:);
    
    
    % Mutation
    popm=repmat(empty_individual,nm,1);
    for k=1:nm
        
        % Select Parent
        i=randi([1 N]);
        p=pop(i);
        
        % Apply Mutation
        popm(k).Position=Mutate(p.Position,mu);
        
        % Evaluate Mutant
        [popm(k).Cost, popm(k).fit]=CostFunction(popm(k).Position);
        
    end
    
    % Create Merged Population
    pop=[pop
         popc
         popm]; %#ok
     
    % Sort Population
    tfit=[pop.fit];
    [tfit, SortOrder]=sort(tfit);
    pop=pop(SortOrder);
    
    % Update Worst Cost
    Worstfit=max(Worstfit,pop(end).fit);
    
    % Truncation
    pop=pop(1:N);
    tfit=tfit(1:N);
    
    % Store Best Solution Ever Found
    BestSol=pop(1);
    
    % Store Best Cost Ever Found
    BestCost(it)=BestSol.fit;
    %best
    if pop(1).fit<bestfitness
        bestfitness=pop(1).fit;
        bestrate=pop(1).Cost(3);
        bestacc=pop(1).Cost(1);
    end
    
end
fitness=bestfitness;
rate=bestrate;
acc=bestacc;
end
