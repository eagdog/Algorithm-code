%% sigmoid transfer
function a=Tranf(x)        %真实位置------>二进制位置                                                   
for i=1:numel(x)
    xt=1/(1+exp(-2*x(i)));  
    if rand<xt
        a(i)=1;
    else
        a(i)=0;
    end
end
