%% 论文总结

%1.CSA算法是最少的参数(AP和FL)
%2.CSA算法用于连续空间，但是特征选择是离散的------传递函数
%       太陡，太平效果不佳，陷入局部最小
%3.提出时变飞行长度
%       tvfl = (1-t/T)tvflmax+t/Ttvflmin    (t当前迭代次数，tvflmax是tvfl最大值。刚开始大，最后小)
%4.原来的位置更新公式
%       Xnew = Xcurrent+fl*randi*(memj,current-xi,current)
%5.现在的位置更新公式(解X的连续搜索空间转换为二进制搜索空间)
%       if randi<T(Xdnew)
 %          Xdnew = 1
 %      else
 %          Xdnew = 0
 %其中Xdnew表示乌鸦在第d维X的位置，randi是[0,1]内的第i次迭代生成的随机数
 %6.特选的适应度函数
 %      Fitness(x) = α Gamma R(X) + Beta (|X|/|N|)
 %Gamma R(X)是分类错误率，|X|表示解决方案X选择的特征数量，|N|表示数据集中的特征总数，
 %α和β是决定FS问题两个目标重要性的两个常量参数, β = (1-α)


function [fitness,rate,acc]=FSCSA(dim,N,CostFunction)


VarSize=[1 dim];   % Size of Decision Variables Matrix

% Number of Objective Functions
nObj=numel(CostFunction(randi([0 1],VarSize))); %目标函数个数


%% BCSA 
pd=dim; % Problem dimension (number of decision variables)
AP=0.1; % Awareness probability
flmax=2.5; % Flight length (fl)
flmin=1.5; % Flight length (fl)
l=-20;u=20;

empty_individual.Position=[];
empty_individual.Cost=[];
empty_individual.RelPos=[];
empty_individual.fit=[];

pop=repmat(empty_individual,N,1);
popnew = repmat(empty_individual,N,1);
%% 初始化种群
%%[x,l,u]=init(N,pd); % Function for initialization就是初始化每个乌鸦的位置
for i=1:N % Generation of initial solutions (position of crows)
    pop(i).RelPos=randi([l u],VarSize); % Position of the crows in the space
    pop(i).Position=Tranf(pop(i).RelPos);
    [ pop(i).Cost,pop(i).fit]=CostFunction(pop(i).Position);
end

popmem = pop;
tmax=300; % Maximum number of iterations (itermax)
%% CSA Main Loop
for t=1:tmax 

    num=ceil(N*rand(1,N)); % Generation of random candidate crows for following (chasing)
    tvfl = ((1-(t/tmax))*flmax+(t/tmax)*flmin)+0.1;
    for i=1:N
            if rand>AP
                 popnew(i).RelPos= pop(i).RelPos+tvfl*rand*(popmem(num(i)).RelPos-pop(i).RelPos); % Generation of a new position for crow i (state 1)

                 popnew(i).Position=Tranf(popnew(i).RelPos);
            else
                 popnew(i).RelPos=randi([l u],VarSize); % Position of the crows in the space
                 popnew(i).Position=Tranf(pop(i).RelPos);
            end
         [ pop(i).Cost,pop(i).fit]=CostFunction(pop(i).Position);
    end
    
    for i=1:N % Update position and memory
        if popnew(i).RelPos>=l & popnew(i).RelPos<=u
            pop(i).RelPos=popnew(i).RelPos; % Update position

            if popnew(i).fit<popmem(i).fit
                popmem(i)=popnew(i); % Update memory
            end
        end
    end
end
    %找最好的
 tfit=[popmem.fit];
 [~,index]=sort(tfit);
popmem=popmem(index);
fitness=popmem(1).fit;
rate=popmem(1).Cost(3);
acc=popmem(1).Cost(1);
end

