function [fitness,rf,accuracy] = jBPSO(data,N,max_Iter,c1,c2,HO)
Wmax = 0.9;
Wmin = 0.4; 
Vmax = 6;

x=data.x;

dim = size(x,2); 
X   = zeros(N,dim);
V   = zeros(N,dim);
%初始化
for i = 1:N
  for d = 1:dim
    if rand() > 0.5
      X(i,d) = 1;
    end
  end
end
%结果数组
fit  = zeros(1,N); 
acc=zeros(1,N);
rate=zeros(1,N);
%全局最优值
fitgbest = inf;
accG=0;
rateG=0;
%计算特选结果值
for i = 1:N
    [acc(i),fit(i),rate(i)] = FSCostFit(X(i,:),data,HO);
    if fit(i) < fitgbest
        Xgbest  = X(i,:);%位置
        fitgbest = fit(i);%位置对应的适应度值
    end
end
Xpbest  = X; 
fitPbest = fit; 

t = 1; 
%---Iterations start-------------------------------------------------
while t <= max_Iter
  w = Wmax - (Wmax - Wmin) * (t / max_Iter);
  for i = 1:N
    for d = 1:dim
      r1    = rand();
      r2    = rand();
      VB    = V(i,d) * w + c1 * r1 * (Xpbest(i,d) - X(i,d)) + ...
              c2 * r2 * (Xgbest(d) - X(i,d)); 
       %限界
      VB(VB > Vmax) = Vmax;  VB(VB < -Vmax) = -Vmax; 
      
      V(i,d) = VB; 
      
      TF     = 1 / (1 + exp(-V(i,d)));
      if TF > rand()
        X(i,d) = 1;
      else
        X(i,d) = 0;
      end
    end
     [acc(i),fit(i),rate(i)] =  FSCostFit(X(i,:),data,HO);
    if fit(i) < fitPbest(i)
      Xpbest(i,:) = X(i,:);
      fitPbest(i)  = fit(i);
    end
    %全局最优更新
    if fitPbest(i) <= fitgbest
      Xgbest  = Xpbest(i,:);
      fitgbest = fitPbest(i);
      accG=acc(i);
      rateG=rate(i);
    end
  end
  
  t = t + 1;
end
fitness=fitgbest;
rf=rateG;
accuracy=accG;
end



