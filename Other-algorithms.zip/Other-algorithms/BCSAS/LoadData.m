function data=LoadData(name)
    path='C:\Users\kiddo\Desktop\study\23-0214\code\对比实验\BCSAS\data\';
    file=name; 
    load([path,file]);
    num_column=numel(DATA(1,:));
    %做实验先取个样本
    data.x=DATA(:,1:num_column-1); %data.x=data.x';%属性*样本=13属性*252样本
    data.t=DATA(:,num_column); %data.t=data.t';%标签

    data.nx=size(data.x,2); %nx是属性数目
    data.nt=size(data.t,1); %nt标签数目
    data.nSample=size(data.x,2); %data.nSample样本个数
end