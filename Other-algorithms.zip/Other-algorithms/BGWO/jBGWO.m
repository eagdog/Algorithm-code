function [acc,fit,rf] = jBGWO(dim,N,max_Iter,CostFunction)

X   = zeros(N,dim);
for i = 1:N
  for d = 1:dim
    if rand() > 0.5
      X(i,d) = 1;
    end
  end
end
Acc = zeros(1,N);
fitness = zeros(1,N);
Rate= zeros(1,N);
for i = 1:N
  [Acc(i),fitness(i),Rate(i)] = CostFunction(X(i,:));
end 
[~, idx] = sort(fitness,'ascend');  
Xalpha   = X(idx(1),:); %当前最优位置
Xbeta    = X(idx(2),:); 
Xdelta   = X(idx(3),:);
Falpha   = fitness(idx(1)); %当前最优适应度值
Fbeta    = fitness(idx(2)); 
Fdelta   = fitness(idx(3));
%最优适应度对应的准确率和比率
AccBest=Acc(idx(1));
RateBest=Rate(idx(1));
t = 1;
%---Iterations start-----------------------------------------------
while t <= max_Iter
  a = 2 - 2 * (t / max_Iter); 
  for i = 1:N
    for d = 1:dim
      C1 = 2 * rand(); 
      C2 = 2 * rand();
      C3 = 2 * rand();
      Dalpha = abs(C1 * Xalpha(d) - X(i,d));
      Dbeta  = abs(C2 * Xbeta(d) - X(i,d));
      Ddelta = abs(C3 * Xdelta(d) - X(i,d));
      A1 = 2 * a * rand() - a; 
      Bstep1 = jBstepBGWO(A1 * Dalpha);
      Bstep2 = jBstepBGWO(A1 * Dbeta); 
      Bstep3 = jBstepBGWO(A1 * Ddelta);
      X1 = jBGWOupdate(Xalpha(d),Bstep1);
      X2 = jBGWOupdate(Xbeta(d),Bstep2);
      X3 = jBGWOupdate(Xdelta(d),Bstep3);
      r  = rand();
      if r < 1/3
        X(i,d) = X1;
      elseif r < 2/3  &&  r >=1/3
        X(i,d) = X2;
      else
        X(i,d) = X3;
      end
    end
  end
  for i = 1:N
      [Acc(i),fitness(i),Rate(i)] = CostFunction(X(i,:));
    if fitness(i) < Falpha
      Falpha = fitness(i);
      Xalpha = X(i,:);
      AccBest=Acc(i);
      RateBest=Rate(i);
    end
    if fitness(i) < Fbeta  &&  fitness(i) > Falpha
      Fbeta = fitness(i); 
      Xbeta = X(i,:);
    end
    if fitness(i) < Fdelta  &&  fitness(i) > Falpha  &&  fitness(i) > Fbeta
      Fdelta = fitness(i);
      Xdelta = X(i,:);
    end
  end
  t = t + 1;
end
acc=AccBest;
fit=Falpha;
rf=RateBest;
end


function Bstep = jBstepBGWO(AD)
Cstep = 1 / (1 + exp(-10 * (AD - 0.5))); 
if Cstep >= rand() 
	Bstep = 1; 
else
	Bstep = 0;
end
end


function Y = jBGWOupdate(X,Bstep) 
if (X + Bstep) >= 1
	Y = 1;
else
  Y = 0;
end
end



