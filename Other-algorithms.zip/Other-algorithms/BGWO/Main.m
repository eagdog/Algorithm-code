%% Binary Grey Wolf Optimization 
clc, clear, close
% Benchmark data set 

%data=LoadData('1haberman.mat');  %0.7525
%data=LoadData('2australia.mat');   %0.8843
%data=LoadData('3balance-scale.mat'); %0.8424
%data=LoadData('4Breastcancer.mat'); %[0,1,0,0,0,1,1,1,1,0] 1
%data=LoadData('5contraceptive.mat'); %0.5418
%data=LoadData('6ecoli.mat');           %0.8741
data=LoadData('7glass.mat');              %0.7971
%data=LoadData('8inosphere.mat');           %0.9829
%data=LoadData('9iris.mat');                        %1
%data=LoadData('10sonar.mat');%
%data=LoadData('11wine.mat');  %1
%data=LoadData('12zoo.mat');   %1
%data=LoadData('13vehicle.mat');%
%data=LoadData('14dermatology.mat'); %
%data=LoadData('15lymphography.mat');  %[0.896551724137931,0.896551724137931,0.862068965517241,0.896551724137931,0.896551724137931,0.862068965517241,0.862068965517241,0.862068965517241,0.896551724137931,0.896551724137931,0.827586206896552,0.862068965517241,0.896551724137931,0.896551724137931,0.827586206896552,0.827586206896552,0.862068965517241,0.896551724137931,0.862068965517241,0.862068965517241,0.862068965517241,0.862068965517241,0.896551724137931,0.896551724137931,0.862068965517241,0.862068965517241,0.827586206896552,0.896551724137931,0.896551724137931,0.862068965517241]
%data=LoadData('16Tic-Tac-Toe.mat'); %[0.759162303664921,0.832460732984293,0.832460732984293,0.832460732984293,0.832460732984293,0.832460732984293,0.832460732984293,0.832460732984293,0.832460732984293,0.832460732984293,0.832460732984293,0.832460732984293,0.832460732984293,0.832460732984293,0.832460732984293,0.764397905759162,0.832460732984293,0.832460732984293,0.832460732984293,0.832460732984293,0.764397905759162,0.769633507853403,0.764397905759162,0.832460732984293,0.764397905759162,0.753926701570681,0.832460732984293,0.832460732984293,0.832460732984293,0.832460732984293]
%data=LoadData('breastEW.mat');  % 0.987
%data=LoadData('SpectHeart.mat');   %0.9082

% Set 20% data as validation set
ho = 0.2; 
% Hold-out method
HO = cvpartition(data.t,'HoldOut',ho,'Stratify',false);
CostFunction=@(r)FSCostFit(r,data,HO);

% Parameter setting
N        = 50; 
max_Iter = 100;
dim=data.nx;             % Number of Decision Variables 
% Binary Grey Wolf Optimization 
sumbfit=0;
sumbrite=0;
sumacc=0;
for i=1:30
    [acc(i),fitness(i),rf(i)] =jBGWO(dim,N,max_Iter,CostFunction);
    sumbfit=sumbfit+fitness(i);
    sumbrite=sumbrite+rf(i);
    sumacc=sumacc+acc(i);
end
    aveacc30=sumacc/30;
    avefit30=sumbfit/30;
    averite30=sumbrite/30;
    
     StdAcc=std(acc);
    StdFit=std(fitness);
    MaxAcc=max(acc);
% Plot convergence curve
    plot(acc,'b*');
    xlabel('acc');
    ylabel('itreter');
    title('30次BGWO准确率的图 ');




