function [fitness,rate,acc]=BCSAV(dim,N,CostFunction)
%% BCSA -V
fl=2;
AP=0.1; % Awareness probability
l=-20;u=20;
VarSize=[1 dim];   % Size of Decision Variables Matrix

empty_individual.Position=[];
empty_individual.Cost=[];
empty_individual.RelPos=[];
empty_individual.fit=[];

pop=repmat(empty_individual,N,1);
popnew = repmat(empty_individual,N,1);

% Generation of initial solutions (position of crows)
for i=1:N 
    pop(i).RelPos=randi([l u],VarSize); % Position of the crows in the space
    pop(i).Position=Tranf(pop(i).RelPos);
    [pop(i).Cost,pop(i).fit]=CostFunction(pop(i).Position);
end

popmem = pop;
tmax=100; % Maximum number of iterations (itermax)
%% CSA Main Loop

for t=1:tmax
    num=ceil(N*rand(1,N)); % Generation of random candidate crows for following (chasing)
    for i=1:N
            if rand>AP
                 popnew(i).RelPos= pop(i).RelPos+fl.*rand.*(popmem(num(i)).RelPos-pop(i).RelPos); % Generation of a new position for crow i (state 1)
            else
               popnew(i).RelPos=randi([l u]);
            end          
        popnew(i).Position=Tranf(popnew(i).RelPos);
        [popnew(i).Cost,popnew(i).fit]=CostFunction(popnew(i).Position);%特选
    end
% Update position and memory    
    for i=1:N 
        if popnew(i).RelPos>=l & popnew(i).RelPos<=u
            pop(i).RelPos=popnew(i).RelPos; % Update position
            if popnew(i).fit<popmem(i).fit
                popmem(i)=popnew(i); % Update memory
            end
        end
    end   
end
    %找最好的
 tfit=[popmem.fit];
 [~,index]=sort(tfit);
popmem=popmem(index);
fitness=popmem(1).fit;
rate=popmem(1).Cost(3);
acc=popmem(1).Cost(1);
end
